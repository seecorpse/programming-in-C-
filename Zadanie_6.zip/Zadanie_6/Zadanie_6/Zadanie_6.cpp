﻿#include <iostream>
#include <string>
using namespace std;

class Pojazd {
private:
    string marka;
    string model;
    int rokProdukcji;

public:
    Pojazd() : marka("Nieznana"), model("Nieznany"), rokProdukcji(0) {}
    Pojazd(const string& marka, const string& model, int rokProdukcji)
        : marka(marka), model(model), rokProdukcji(rokProdukcji) {}
    void setMarka(const string& marka) { this->marka = marka; }
    void setModel(const string& model) { this->model = model; }
    void setRokProdukcji(int rokProdukcji) { this->rokProdukcji = rokProdukcji; }
    string getMarka() const { return marka; }
    string getModel() const { return model; }
    int getRokProdukcji() const { return rokProdukcji; }

    virtual void wyswietlDane() const {
        cout << "Marka: " << marka << "\nModel: " << model << "\nRok produkcji: " << rokProdukcji << endl;
    }

    virtual ~Pojazd() {}
};
class SamochodCiezarowy : public Pojazd {
private:
    string przeznaczenie;

public:
    SamochodCiezarowy() : Pojazd(), przeznaczenie("Nieznane") {}
    SamochodCiezarowy(const string& marka, const string& model, int rokProdukcji, const string& przeznaczenie)
        : Pojazd(marka, model, rokProdukcji), przeznaczenie(przeznaczenie) {}
    void setPrzeznaczenie(const string& przeznaczenie) { this->przeznaczenie = przeznaczenie; }
    string getPrzeznaczenie() const { return przeznaczenie; }

    void wyswietlDane() const override {
        cout << "Typ pojazdu: Samochód ciężarowy\n";
        Pojazd::wyswietlDane();
        cout << "Przeznaczenie: " << przeznaczenie << endl;
    }
};
class Autobus : public Pojazd {
private:
    int miejscaSiedzace;
    int miejscaStojace;

public:
    Autobus() : Pojazd(), miejscaSiedzace(0), miejscaStojace(0) {}
    Autobus(const string& marka, const string& model, int rokProdukcji, int miejscaSiedzace, int miejscaStojace)
        : Pojazd(marka, model, rokProdukcji), miejscaSiedzace(miejscaSiedzace), miejscaStojace(miejscaStojace) {}
    void setMiejscaSiedzace(int miejscaSiedzace) { this->miejscaSiedzace = miejscaSiedzace; }
    void setMiejscaStojace(int miejscaStojace) { this->miejscaStojace = miejscaStojace; }
    int getMiejscaSiedzace() const { return miejscaSiedzace; }
    int getMiejscaStojace() const { return miejscaStojace; }

    void wyswietlDane() const override {
        cout << "Typ pojazdu: Autobus\n";
        Pojazd::wyswietlDane();
        cout << "Miejsca siedzące: " << miejscaSiedzace << "\nMiejsca stojące: " << miejscaStojace << endl;
    }
};
void testAutobus() {
    string marka, model;
    int rokProdukcji, miejscaSiedzace, miejscaStojace;

    cout << "Podaj markę autobusu: ";
    cin >> marka;
    cout << "Podaj model autobusu: ";
    cin >> model;
    cout << "Podaj rok produkcji autobusu: ";
    cin >> rokProdukcji;
    cout << "Podaj liczbę miejsc siedzących: ";
    cin >> miejscaSiedzace;
    cout << "Podaj liczbę miejsc stojących: ";
    cin >> miejscaStojace;
    Autobus autobus(marka, model, rokProdukcji, miejscaSiedzace, miejscaStojace);

    cout << "\nDane autobusu:\n";
    autobus.wyswietlDane();
}

int main() {
    testAutobus();
    return 0;
}
