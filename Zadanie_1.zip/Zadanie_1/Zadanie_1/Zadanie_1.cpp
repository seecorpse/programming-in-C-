﻿#include <iostream>
#include <string>

using namespace std;
class Komputer {
protected:
    string marka;
    string model;

public:
    Komputer(string m = "", string mo = "") : marka(m), model(mo) {}
    virtual void wyswietlDane() const {
        cout << "Marka: " << marka << endl;
        cout << "Model: " << model << endl;
    }
    virtual void wprowadzDane() {
        cout << "Podaj markę: ";
        cin >> marka;
        cout << "Podaj model: ";
        cin >> model;
    }
};
class PC : public Komputer {
private:
    string rodzajObudowy;

public:
    PC(string m = "", string mo = "", string ro = "") : Komputer(m, mo), rodzajObudowy(ro) {}
    void wprowadzDane() override {
        Komputer::wprowadzDane();
        cout << "Podaj rodzaj obudowy: ";
        cin >> rodzajObudowy;
    }
    void wyswietlDane() const override {
        Komputer::wyswietlDane();
        cout << "Rodzaj obudowy: " << rodzajObudowy << endl;
    }
};
class Laptop : public Komputer {
private:
    double przekatnaEkranu;
    string kolorObudowy;
public:
    Laptop(string m = "", string mo = "", double pe = 0.0, string ko = "")
        : Komputer(m, mo), przekatnaEkranu(pe), kolorObudowy(ko) {}
    void wprowadzDane() override {
        Komputer::wprowadzDane();
        cout << "Podaj długość przekątnej ekranu (w calach): ";
        cin >> przekatnaEkranu;
        cout << "Podaj kolor obudowy: ";
        cin >> kolorObudowy;
    }
    void wyswietlDane() const override {
        Komputer::wyswietlDane();
        cout << "Przekątna ekranu: " << przekatnaEkranu << " cali" << endl;
        cout << "Kolor obudowy: " << kolorObudowy << endl;
    }
};
int main() {
    Laptop laptop;
    cout << "Wprowadź dane laptopa:" << endl;
    laptop.wprowadzDane();

    cout << "\nDane wprowadzonego laptopa:" << endl;
    laptop.wyswietlDane();

    return 0;
}
