﻿#include <iostream>
#include <string>
using namespace std;

class Pracownik {
protected:
    string imie;
    string nazwisko;
    int wiek;
public:
    Pracownik(const string& imie, const string& nazwisko, int wiek)
        : imie(imie), nazwisko(nazwisko), wiek(wiek) {}

    virtual void wyswietlDane() const {
        cout << "Imię: " << imie << "\nNazwisko: " << nazwisko << "\nWiek: " << wiek << endl;
    }

    virtual ~Pracownik() {}
};
class Dyrektor : public Pracownik {
public:
    Dyrektor(const string& imie, const string& nazwisko, int wiek)
        : Pracownik(imie, nazwisko, wiek) {}

    void wyswietlDane() const override {
        cout << "Stanowisko: Dyrektor\n";
        Pracownik::wyswietlDane();
    }
};
class Nauczyciel : public Pracownik {
protected:
    string przedmiot;
public:
    Nauczyciel(const string& imie, const string& nazwisko, int wiek, const string& przedmiot)
        : Pracownik(imie, nazwisko, wiek), przedmiot(przedmiot) {}

    void wyswietlDane() const override {
        cout << "Stanowisko: Nauczyciel\n";
        Pracownik::wyswietlDane();
        cout << "Przedmiot: " << przedmiot << endl;
    }
};
class Wychowawca : public Nauczyciel {
private:
    string klasaWychowawcza;
public:
    Wychowawca(const string& imie, const string& nazwisko, int wiek, const string& przedmiot, const string& klasaWychowawcza)
        : Nauczyciel(imie, nazwisko, wiek, przedmiot), klasaWychowawcza(klasaWychowawcza) {}

    void wyswietlDane() const override {
        cout << "Stanowisko: Wychowawca\n";
        Pracownik::wyswietlDane();
        cout << "Przedmiot: " << przedmiot << "\nKlasa wychowawcza: " << klasaWychowawcza << endl;
    }
};
class Sekretarka : public Pracownik {
public:
    Sekretarka(const string& imie, const string& nazwisko, int wiek)
        : Pracownik(imie, nazwisko, wiek) {}

    void wyswietlDane() const override {
        cout << "Stanowisko: Sekretarka\n";
        Pracownik::wyswietlDane();
    }
};
void testWychowawca() {
    string imie, nazwisko, przedmiot, klasaWychowawcza;
    int wiek;

    cout << "Podaj imię wychowawcy: ";
    cin >> imie;
    cout << "Podaj nazwisko wychowawcy: ";
    cin >> nazwisko;
    cout << "Podaj wiek wychowawcy: ";
    cin >> wiek;
    cout << "Podaj przedmiot wychowawcy: ";
    cin >> przedmiot;
    cout << "Podaj klasę wychowawczą: ";
    cin >> klasaWychowawcza;

    Wychowawca wychowawca(imie, nazwisko, wiek, przedmiot, klasaWychowawcza);
    cout << "\nDane wychowawcy:\n";
    wychowawca.wyswietlDane();
}

int main() {
    testWychowawca();
    return 0;
}
