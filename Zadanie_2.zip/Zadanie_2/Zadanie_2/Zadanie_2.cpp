﻿#include <iostream>
#include <string>
using namespace std;

class Komputer {
private:
    string marka;
    string model;

public:
    Komputer(string m = "", string mo = "") : marka(m), model(mo) {}
    string getMarka() const { return marka; }
    string getModel() const { return model; }
    void setMarka(const string& m) { marka = m; }
    void setModel(const string& mo) { model = mo; }
    virtual void wyswietlDane() const {
        cout << "Marka: " << marka << endl;
        cout << "Model: " << model << endl;
    }
    virtual void wprowadzDane() {
        string temp;
        cout << "Podaj markę: ";
        cin >> temp;
        setMarka(temp);
        cout << "Podaj model: ";
        cin >> temp;
        setModel(temp);
    }
};
class PC : public Komputer {
private:
    string rodzajObudowy;

public:
    PC(string m = "", string mo = "", string ro = "") : Komputer(m, mo), rodzajObudowy(ro) {}
    string getRodzajObudowy() const { return rodzajObudowy; }
    void setRodzajObudowy(const string& ro) { rodzajObudowy = ro; }
    void wprowadzDane() override {
        Komputer::wprowadzDane();
        string temp;
        cout << "Podaj rodzaj obudowy: ";
        cin >> temp;
        setRodzajObudowy(temp);
    }
    void wyswietlDane() const override {
        Komputer::wyswietlDane();
        cout << "Rodzaj obudowy: " << getRodzajObudowy() << endl;
    }
};
class Laptop : public Komputer {
private:
    double przekatnaEkranu;
    string kolorObudowy;
public:
    Laptop(string m = "", string mo = "", double pe = 0.0, string ko = "")
        : Komputer(m, mo), przekatnaEkranu(pe), kolorObudowy(ko) {}
    double getPrzekatnaEkranu() const { return przekatnaEkranu; }
    void setPrzekatnaEkranu(double pe) { przekatnaEkranu = pe; }

    string getKolorObudowy() const { return kolorObudowy; }
    void setKolorObudowy(const string& ko) { kolorObudowy = ko; }
    void wprowadzDane() override {
        Komputer::wprowadzDane();
        double tempPrzekatna;
        string tempKolor;

        cout << "Podaj długość przekątnej ekranu (w calach): ";
        cin >> tempPrzekatna;
        setPrzekatnaEkranu(tempPrzekatna);

        cout << "Podaj kolor obudowy: ";
        cin >> tempKolor;
        setKolorObudowy(tempKolor);
    }
    void wyswietlDane() const override {
        Komputer::wyswietlDane();
        cout << "Przekątna ekranu: " << getPrzekatnaEkranu() << " cali" << endl;
        cout << "Kolor obudowy: " << getKolorObudowy() << endl;
    }
};
int main() {
    Laptop laptop;
    cout << "Wprowadź dane laptopa:" << endl;
    laptop.wprowadzDane();

    cout << "\nDane wprowadzonego laptopa:" << endl;
    laptop.wyswietlDane();

    return 0;
}
