﻿#include <iostream>
#include <string>
using namespace std;

class Pracownik {
private:
    string imie;
    string nazwisko;
    int wiek;

public:
    Pracownik() : imie("Nieznane"), nazwisko("Nieznane"), wiek(0) {}
    Pracownik(const string& imie, const string& nazwisko, int wiek)
        : imie(imie), nazwisko(nazwisko), wiek(wiek) {}
    void setImie(const string& imie) { this->imie = imie; }
    void setNazwisko(const string& nazwisko) { this->nazwisko = nazwisko; }
    void setWiek(int wiek) { this->wiek = wiek; }
    string getImie() const { return imie; }
    string getNazwisko() const { return nazwisko; }
    int getWiek() const { return wiek; }
    virtual void wyswietlDane() const {
        cout << "Imię: " << imie << "\nNazwisko: " << nazwisko << "\nWiek: " << wiek << endl;
    }
    virtual ~Pracownik() {}
};
class Dyrektor : public Pracownik {
public:
    Dyrektor() : Pracownik() {}
    Dyrektor(const string& imie, const string& nazwisko, int wiek)
        : Pracownik(imie, nazwisko, wiek) {}

    void wyswietlDane() const override {
        cout << "Stanowisko: Dyrektor\n";
        Pracownik::wyswietlDane();
    }
};
class Nauczyciel : public Pracownik {
private:
    string przedmiot;
public:
    Nauczyciel() : Pracownik(), przedmiot("Nieznany") {}
    Nauczyciel(const string& imie, const string& nazwisko, int wiek, const string& przedmiot)
        : Pracownik(imie, nazwisko, wiek), przedmiot(przedmiot) {}
    void setPrzedmiot(const string& przedmiot) { this->przedmiot = przedmiot; }
    string getPrzedmiot() const { return przedmiot; }
    void wyswietlDane() const override {
        cout << "Stanowisko: Nauczyciel\n";
        Pracownik::wyswietlDane();
        cout << "Przedmiot: " << przedmiot << endl;
    }
};
class Wychowawca : public Nauczyciel {
private:
    string klasaWychowawcza;

public:
    Wychowawca() : Nauczyciel(), klasaWychowawcza("Nieznana") {}
    Wychowawca(const string& imie, const string& nazwisko, int wiek, const string& przedmiot, const string& klasaWychowawcza)
        : Nauczyciel(imie, nazwisko, wiek, przedmiot), klasaWychowawcza(klasaWychowawcza) {}
    void setKlasaWychowawcza(const string& klasaWychowawcza) { this->klasaWychowawcza = klasaWychowawcza; }
    string getKlasaWychowawcza() const { return klasaWychowawcza; }

    void wyswietlDane() const override {
        cout << "Stanowisko: Wychowawca\n";
        Pracownik::wyswietlDane();
        cout << "Przedmiot: " << getPrzedmiot() << "\nKlasa wychowawcza: " << klasaWychowawcza << endl;
    }
};
class Sekretarka : public Pracownik {
public:
    Sekretarka() : Pracownik() {}
    Sekretarka(const string& imie, const string& nazwisko, int wiek)
        : Pracownik(imie, nazwisko, wiek) {}

    void wyswietlDane() const override {
        cout << "Stanowisko: Sekretarka\n";
        Pracownik::wyswietlDane();
    }
};
void testWychowawca() {
    string imie, nazwisko, przedmiot, klasaWychowawcza;
    int wiek;

    cout << "Podaj imię wychowawcy: ";
    cin >> imie;
    cout << "Podaj nazwisko wychowawcy: ";
    cin >> nazwisko;
    cout << "Podaj wiek wychowawcy: ";
    cin >> wiek;
    cout << "Podaj przedmiot wychowawcy: ";
    cin >> przedmiot;
    cout << "Podaj klasę wychowawczą: ";
    cin >> klasaWychowawcza;
    Wychowawca wychowawca(imie, nazwisko, wiek, przedmiot, klasaWychowawcza);

    cout << "\nDane wychowawcy:\n";
    wychowawca.wyswietlDane();
}
int main() {
    testWychowawca();
    return 0;
}
